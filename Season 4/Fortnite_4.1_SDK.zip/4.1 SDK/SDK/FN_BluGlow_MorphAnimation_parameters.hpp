#pragma once

// Fortnite SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BluGlow_MorphAnimation.BluGlow_MorphAnimation_C.UserConstructionScript
struct ABluGlow_MorphAnimation_C_UserConstructionScript_Params
{
};

// Function BluGlow_MorphAnimation.BluGlow_MorphAnimation_C.Timeline_0__FinishedFunc
struct ABluGlow_MorphAnimation_C_Timeline_0__FinishedFunc_Params
{
};

// Function BluGlow_MorphAnimation.BluGlow_MorphAnimation_C.Timeline_0__UpdateFunc
struct ABluGlow_MorphAnimation_C_Timeline_0__UpdateFunc_Params
{
};

// Function BluGlow_MorphAnimation.BluGlow_MorphAnimation_C.Timeline_0__ChangeTargetFrame__EventFunc
struct ABluGlow_MorphAnimation_C_Timeline_0__ChangeTargetFrame__EventFunc_Params
{
};

// Function BluGlow_MorphAnimation.BluGlow_MorphAnimation_C.ReceiveBeginPlay
struct ABluGlow_MorphAnimation_C_ReceiveBeginPlay_Params
{
};

// Function BluGlow_MorphAnimation.BluGlow_MorphAnimation_C.ExecuteUbergraph_BluGlow_MorphAnimation
struct ABluGlow_MorphAnimation_C_ExecuteUbergraph_BluGlow_MorphAnimation_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
