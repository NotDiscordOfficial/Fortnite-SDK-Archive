#pragma once

#include "../SDK.h"

// Name: Fortnite, Version: 1.8.2

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function MediaAssets.MediaOverlays.GetTexts
struct UMediaOverlays_GetTexts_Params
{
};

// Function MediaAssets.MediaOverlays.GetSubtitles
struct UMediaOverlays_GetSubtitles_Params
{
};

// Function MediaAssets.MediaOverlays.GetCaptions
struct UMediaOverlays_GetCaptions_Params
{
};

// Function MediaAssets.FileMediaSource.SetFilePath
struct UFileMediaSource_SetFilePath_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
