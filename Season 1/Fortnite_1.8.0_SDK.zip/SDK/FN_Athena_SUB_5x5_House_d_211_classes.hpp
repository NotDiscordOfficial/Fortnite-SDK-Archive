#pragma once

// Fortnite (1.8) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Athena_SUB_5x5_House_d_211.Athena_SUB_5x5_House_d_C
// 0x0000 (0x03A0 - 0x03A0)
class AAthena_SUB_5x5_House_d_C : public AFortLevelScriptActor
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Athena_SUB_5x5_House_d_211.Athena_SUB_5x5_House_d_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
