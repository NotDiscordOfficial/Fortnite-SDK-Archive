#pragma once

// Fortnite (1.8) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AthenaAircraft.AthenaAircraft_C.UserConstructionScript
struct AAthenaAircraft_C_UserConstructionScript_Params
{
};

// Function AthenaAircraft.AthenaAircraft_C.PlayEffectsForPlayerJumped
struct AAthenaAircraft_C_PlayEffectsForPlayerJumped_Params
{
};

// Function AthenaAircraft.AthenaAircraft_C.ExecuteUbergraph_AthenaAircraft
struct AAthenaAircraft_C_ExecuteUbergraph_AthenaAircraft_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
