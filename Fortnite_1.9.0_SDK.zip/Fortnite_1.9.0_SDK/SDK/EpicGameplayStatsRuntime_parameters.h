#pragma once

#include "../SDK.h"

// Name: Fortnite, Version: 1.9.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function EpicGameplayStatsRuntime.BlueprintGameplayStatsLibrary.NotEqual_GameplayStatTagGameplayStatTag
struct UBlueprintGameplayStatsLibrary_NotEqual_GameplayStatTagGameplayStatTag_Params
{
	struct FGameplayStatTag                            A;                                                        // (Parm)
	struct FGameplayStatTag                            B;                                                        // (Parm)
};

// Function EpicGameplayStatsRuntime.BlueprintGameplayStatsLibrary.EqualEqual_GameplayStatTagGameplayStatTag
struct UBlueprintGameplayStatsLibrary_EqualEqual_GameplayStatTagGameplayStatTag_Params
{
	struct FGameplayStatTag                            A;                                                        // (Parm)
	struct FGameplayStatTag                            B;                                                        // (Parm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
