#pragma once

// Name: Fortnite, Version: 1.9.0

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// Enum Hotfix.EHotfixResult
enum class EHotfixResult : uint8_t
{

};


// Enum Hotfix.EPatchCheckResult
enum class EPatchCheckResult : uint8_t
{

};


// Enum Hotfix.EUpdateCompletionStatus
enum class EUpdateCompletionStatus : uint8_t
{

};


// Enum Hotfix.EUpdateState
enum class EUpdateState : uint8_t
{

};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
